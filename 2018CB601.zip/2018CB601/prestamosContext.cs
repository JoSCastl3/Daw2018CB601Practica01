using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.SqlServer;
using _2018CB601.Models;

namespace _2018CB601
{
        public class prestamosContext : DbContext
    {
        public prestamosContext(DbContextOptions<prestamosContext> options) : base(options)
        {            
        }

        public DbSet<equipos> equipos {get; set;}
    }
}